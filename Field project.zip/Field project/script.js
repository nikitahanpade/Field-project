function showDetails(bikeType) {
    let packageInfo = "";
    
    // Define package details based on bike type
    if (bikeType === 'splendor') {
        packageInfo = `
            <h2>Splendor</h2>
            <p><strong>Rental Packages:</strong></p>
            <ul>
                <li>Daily: $20</li>
                <li>Weekly: $120</li>
                <li>Monthly: $400</li>
            </ul>
            <p><strong>Nearby Shops:</strong> Shop A, Shop B, Shop C</p>`;
    } else if (bikeType === 'scooter') {
        packageInfo = `
            <h2>Scooter</h2>
            <p><strong>Rental Packages:</strong></p>
            <ul>
                <li>Daily: $30</li>
                <li>Weekly: $180</li>
                <li>Monthly: $600</li>
            </ul>
            <p><strong>Nearby Shops:</strong> Shop D, Shop E, Shop F</p>`;
    } else if (bikeType === 'enfield') {
        packageInfo = `
            <h2>Royal Enfield Bullet</h2>
            <p><strong>Rental Packages:</strong></p>
            <ul>
                <li>Daily: $25</li>
                <li>Weekly: $150</li>
                <li>Monthly: $500</li>
            </ul>
            <p><strong>Nearby Shops:</strong> Shop G, Shop H, Shop I</p>`;
    }

    // Open a new window and display the HTML content
    const detailsWindow = window.open('', '_blank', 'width=500,height=600');
    detailsWindow.document.write(`
        <html>
        <head>
            <title>Bike Rental Information</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; color: #333; background-color: #f9f9f9; }
                h2 { color: #007bff; }
                p, ul { font-size: 1em; line-height: 1.5em; color: #555; }
                ul { list-style-type: disc; margin-left: 20px; }
            </style>
        </head>
        <body>
            ${packageInfo}
        </body>
        </html>
    `);
    detailsWindow.document.close();
}

  // Function to display additional info when specific questions are selected
function showAdditionalInfo(value) {
    const infoBox = document.getElementById('additional-info');
    const infoText = document.getElementById('info-text');
    


    if (value === 'fuel') {
        infoText.textContent = "It depends on the rental service. Some renters provide a full tank, while others offer a limited amount. Be sure to confirm the rental terms. If you want a full tank arranged, additional charges may apply.";
        infoBox.style.display = 'block';
    } else if (value === 'delivery') {
        infoText.textContent = "Many rental services offer both options. You can pick up the bike yourself or opt for home delivery for a small fee. Confirm the details with the provider during booking.";
        infoBox.style.display = 'block';
    } else if (value === 'outstation') {
        infoText.textContent = "Yes, but confirm with the rental service. Some may require a security deposit or specific documentation for long trips.";
        infoBox.style.display = 'block';
    } else if (value === 'pricing') {
        infoText.textContent = "Rental costs range from ₹300 to ₹1,000 per day, depending on the bike model and rental duration. Additional charges may apply for insurance or helmets.";
        infoBox.style.display = 'block';
    } else if (value === 'documents') {
        infoText.textContent = "You’ll usually need a valid driver’s license, a government-issued ID, and sometimes a security deposit. Confirm with the provider for exact requirements.";
        infoBox.style.display = 'block';
    } else {
        infoBox.style.display = 'none';
    }
}

 // Function to open the modal and load booking.html
 function openModal() {
    document.getElementById("bookingModal").style.display = "block";
    loadBookingForm(); // Load the booking form when modal opens
}

// Function to close the modal
function closeModal() {
    document.getElementById("bookingModal").style.display = "none";
}

// Function to load booking.html into the modal
function loadBookingForm() {
    const bookingContainer = document.getElementById('bookingFormContainer');
    fetch("booking.html") // Ensure this path is correct
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(html => {
            bookingContainer.innerHTML = html; // Inject the HTML content
        })
        .catch(error => {
            bookingContainer.innerHTML = '<p>Error loading booking form.</p>';
            console.error('There was a problem with the fetch operation:', error);
        });
    }
