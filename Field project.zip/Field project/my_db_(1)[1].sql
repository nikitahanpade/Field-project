-- 1. Database Creation
CREATE DATABASE IF NOT EXISTS BikeRentalService;
USE BikeRentalService;

-- 2. User Login Table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Bike Details Table
CREATE TABLE IF NOT EXISTS bikes (
    bike_id INT AUTO_INCREMENT PRIMARY KEY,
    bike_name VARCHAR(100) NOT NULL,
    description TEXT,
    daily_price DECIMAL(10, 2),
    weekly_price DECIMAL(10, 2),
    monthly_price DECIMAL(10, 2),
    available BOOLEAN DEFAULT TRUE,
    image_url VARCHAR(255)
);

-- Insert Sample Bikes
INSERT INTO bikes (bike_name, description, daily_price, weekly_price, monthly_price, available, image_url)
VALUES 
    ('Splendor', 'Experience the thrill of off-road riding.', 20.00, 120.00, 400.00, TRUE, 'photo5.jpg'),
    ('Scooter', 'Perfect for long rides on smooth roads.', 30.00, 180.00, 600.00, TRUE, 'photo7.jpg'),
    ('Royal Enfield Bullet', 'Enjoy a relaxed and comfortable ride.', 25.00, 150.00, 500.00, TRUE, 'photo6.jpg');

-- 4. Booking Table
CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    bike_id INT,
    booking_date DATE,
    return_date DATE,
    total_price DECIMAL(10, 2),
    status ENUM('pending', 'confirmed', 'canceled') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (bike_id) REFERENCES bikes(bike_id)
);

-- 5. Contact Messages Table
CREATE TABLE IF NOT EXISTS contact_messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. FAQ Questions Table
CREATE TABLE IF NOT EXISTS faq_questions (
    faq_id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(100) NOT NULL,
    user_email VARCHAR(100) NOT NULL,
    question TEXT NOT NULL,
    question_type ENUM('fuel', 'delivery', 'outstation', 'pricing', 'documents') NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
