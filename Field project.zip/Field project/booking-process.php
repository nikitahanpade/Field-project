<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $bikeType = $_POST['bike-type'];
    $rentalDays = $_POST['rental-days'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $idType = $_POST['id-type'];
    $idNumber = $_POST['id-number'];
    $paymentMethod = $_POST['payment-method'];

    // Display a confirmation message
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Booking Confirmation</title>
        <style>
            body {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                font-family: Arial, sans-serif;
            }
            .confirmation {
                text-align: center;
                background-color: #f4f4f9;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                width: 400px;
            }
            .confirmation h2 {
                color: #007bff;
            }
            .back-btn {
                background-color: #007bff;
                color: #fff;
                padding: 10px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 1em;
                margin-top: 20px;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class='confirmation'>
            <h2>Thank You, $name!</h2>
            <p>Your booking for a $bikeType for $rentalDays days has been confirmed.</p>
            <p>Payment Method: $paymentMethod</p>
            <p>We’ve sent a confirmation to $email.</p>
            <a href='index.html' class='back-btn'>Back to Home</a>
        </div>
    </body>
    </html>";
} else {
    // Redirect back to booking form if accessed directly
    header("Location: index.html");
    exit();
}
?>
